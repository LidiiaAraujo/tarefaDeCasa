Existem apenas páginas que são um pouco semelhantes ao Instagram.

Exemplos de treinamento.
